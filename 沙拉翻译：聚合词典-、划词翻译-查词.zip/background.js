try {importScripts('assets/browser-polyfill.min.js')} catch(e) {console.error(e)}
try {importScripts('assets/runtime.f561ecd9.js')} catch(e) {console.error(e)}
try {importScripts('assets/view-vendor.f80079ac.js')} catch(e) {console.error(e)}
try {importScripts('assets/franc.f717fc19.js')} catch(e) {console.error(e)}
try {importScripts('assets/dexie.a55bde01.js')} catch(e) {console.error(e)}
try {importScripts('assets/20.f2fbbb89.js')} catch(e) {console.error(e)}
try {importScripts('assets/background.ecf3904c.js')} catch(e) {console.error(e)}